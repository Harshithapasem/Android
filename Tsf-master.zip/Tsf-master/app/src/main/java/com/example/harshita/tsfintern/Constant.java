package com.example.harshita.tsfintern;

public class Constant {
    public static final   String BASE_URL="http://139.59.65.145:9090";
}
